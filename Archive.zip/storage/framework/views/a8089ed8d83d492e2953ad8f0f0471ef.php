<?php $__env->startSection('content'); ?>
    <div class="layout-px-spacing">

        <div class="middle-content container-xxl p-0">

            <!-- BREADCRUMB -->
            <?php echo $__env->make('partials.__breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /BREADCRUMB -->

            <div class="row layout-top-spacing">
                <div class="col-lg-5 col-md-5 col-sm-12 mb-4">
                    <input id="search-input" type="text" name="search" placeholder="Search" class="form-control" value="<?php echo e(request()->search); ?>">
                </div>
                
                <div class="col-lg-7 col-md-7 col-sm-12 mb-4">
                    <form method="GET" action="<?php echo e(route('admin.blog.index')); ?>">  
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <select class="form-select" name="category">
                                    <option value="All Category" <?php echo e(request()->category == 'All Category' ? 'selected' : ''); ?>>Toutes les catégories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e(request()->category == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <select class="form-select" name="sort">
                                    <option value="Recent" <?php echo e(request()->sort == 'Recent' ? 'selected' : ''); ?>>Récents</option>
                                    <option value="Popular" <?php echo e(request()->sort == 'Popular' ? 'selected' : ''); ?>>Populaire</option>
                                </select>
                            </div>

                            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                                <button type="submit" class="btn btn-primary w-100 p-2">Filtrer</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="row">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-4 post-item">
                    <a href="<?php echo e(route('admin.blog.show', $post->id)); ?>" class="card style-2 mb-md-0 mb-4">
                        <img src="<?php echo e($post->image ? asset($post->image) : ''); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>">
                        <div class="card-body px-0 pb-0">
                            <h5 class="card-title mb-3 post-title"><?php echo e($post->title); ?></h5>
                            <div class="media mt-4 mb-0 pt-1">
                                <img src="<?php echo e($post->user->profile_image ?? asset('assets/images/default_user.jpeg')); ?>" class="card-media-image me-3" alt="">
                                <div class="media-body">
                                    <h4 class="media-heading mb-1"><?php echo e($post->user->name ?? null); ?></h4>
                                    <p class="media-text"><?php echo e($post->created_at->format('d M Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
        
    </div> 

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('search-input');
            const posts = document.querySelectorAll('.post-item');
    
            searchInput.addEventListener('keyup', function () {
                const searchQuery = this.value.toLowerCase();
    
                posts.forEach(post => {
                    const title = post.querySelector('.post-title').textContent.toLowerCase();
                    // Filtrer par titre (ajouter d'autres éléments à rechercher si nécessaire)
                    if (title.includes(searchQuery)) {
                        post.style.display = '';
                    } else {
                        post.style.display = 'none';
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/IvoirePuis87/resources/views/backend/blog/index.blade.php ENDPATH**/ ?>