<div class="cmt-page-title-row cmt-bgimage-yes cmt-bg cmt-bgcolor-darkgrey">
    <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
    <div class="cmt-page-title-row-inner">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="page-title-heading">
                        <h2 class="title"><?php echo e($pagetitle); ?></h2>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <span>
                            <a title="Accueil" href="<?php echo e(route('home')); ?>">Accueil</a>
                        </span>
                        <span><?php echo e($pagetitle); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>                    
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/IvoirePuis87/resources/views/partials/pagetitle.blade.php ENDPATH**/ ?>