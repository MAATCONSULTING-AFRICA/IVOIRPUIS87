<?php $__env->startSection('content'); ?>

<!-- START homemainclassicslider REVOLUTION SLIDER 6.1.0 -->
<?php echo $__env->make('partials.pagetitle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END REVOLUTION SLIDER -->


 <!--site-main start-->
 <div class="site-main">
        

    <section class="cmt-row grid-section clearfix">
        <div class="container">
            <div class="row mt_15 mb_15">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cmt-box-col-wrapper col-lg-4 col-md-4 col-sm-6">
                    <!-- featured-imagebox -->
                    <div class="featured-imagebox featured-imagebox-portfolio cmt-bgcolor-darkgrey style1">
                        <!-- cmt-box-view-overlay -->
                        <div class="cmt-box-view-overlay">
                            <!-- featured-thumbnail -->
                            <div class="featured-thumbnail">
                                <a href="<?php echo e(route('portfolio_detail', $portfolio->id)); ?>">
                                 <img class="img-fluid" src="<?php echo e($portfolio->image ? asset($portfolio->image) : ''); ?>" alt="<?php echo e($portfolio->title); ?>">
                                </a>
                            </div><!-- featured-thumbnail end-->
                            <div class="featured-content">
                                <div class="featured-desc">
                                    <p><?php echo e(\Illuminate\Support\Str::limit(strip_tags($portfolio->description), 20, '...')); ?></p>
                                </div>
                                <div class="featured-title">
                                    <h5><a href="<?php echo e(route('portfolio_detail', $portfolio->id)); ?>"><?php echo e($portfolio->title); ?></a></h5>
                                </div>
                                <a class="cmt-btn cmt-btn-size-sm cmt-btn-shape-round cmt-btn-style-fill cmt-btn-color-skincolor" href="<?php echo e(route('portfolio_detail', $portfolio->id)); ?>">Plus de détail</a>
                            </div>
                        </div><!-- cmt-box-view-overlay end-->
                    </div><!-- featured-imagebox -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


</div><!--site-main end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/IvoirePuis87/resources/views/portefeuille.blade.php ENDPATH**/ ?>