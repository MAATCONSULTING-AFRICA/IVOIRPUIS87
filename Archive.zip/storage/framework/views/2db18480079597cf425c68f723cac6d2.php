<?php $__env->startSection('content'); ?>

<div class="layout-px-spacing">

    <div class="middle-content container-xxl p-0">

        <!-- BREADCRUMB -->
        <?php echo $__env->make('partials.__breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /BREADCRUMB -->
        <div class="row layout-top-spacing">   
            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-4">
                <div class="text-end mt-4 mb-4">
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary me-3">
                        Retour
                    </a>
                    <a href="<?php echo e(route('admin.blog.edit', $post->id)); ?>" class="btn btn-success">
                        Modifier le post
                    </a>
                </div>  
                <div class="single-post-content">

                    <div class="featured-image" style="position: relative; background: lightblue url(<?php echo e($post->image); ?>) no-repeat fixed center; height: 650px; background-position: center; background-size: cover; background-attachment: inherit; border-radius: 20px; overflow: hidden;">

                        <div class="featured-image-overlay"></div>

                        <div class="post-header">
                            
                            <div class="post-title">
                                <h1 class="mb-0"><?php echo e($post->title); ?></h1>
                                <p class="category"><?php echo e($post->category->name); ?></p> <!-- Affichage de la catégorie -->
                            </div>
                            
                            <div class="post-meta-info d-flex justify-content-between">

                                <div class="media">
                                    <img src="<?php echo e($post->user->profile_image ?? asset('assets/images/default_user.jpeg')); ?>" alt="<?php echo e($post->title); ?>">
                                    <div class="media-body">
                                        <h5><?php echo e($post->user->name); ?></h5>
                                        <p><?php echo e($post->created_at->format('d M Y')); ?></p>
                                    </div>
                                </div>

                                <div class="align-self-center">
                                    <button class="btn btn-success btn-icon btn-share btn-rounded">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-share-2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                                    </button>
                                </div>
                                
                            </div>

                        </div>
                        
                    </div>

                    <div class="post-content">
                        <?php echo html_entity_decode($post->content); ?>

                    </div>

                    <div class="post-info">
                        
                        <hr>

                        <div class="post-tags mt-5">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-primary mb-2"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="post-dynamic-meta mt-5 mb-5">
                            <button class="btn btn-secondary me-4 mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                                <span class="btn-text-inner">1.1k</span> <!-- Nombre de likes si disponible -->
                            </button>
                            
                            <div class="avatar--group mb-2">
                                <?php if($post->likes && $post->likes->count()): ?>
                                    <?php $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="avatar avatar-sm m-0">
                                            <img alt="avatar" src="<?php echo e($like->user->profile_image ?? asset('assets/images/default_user.jpeg')); ?>" class="rounded-circle">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>Pas de likes.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <hr>

                        <h2 class="mb-5">Commentaires <span class="comment-count">(<?php echo e($post->comments->count()); ?>)</span></h2>

                        <div class="post-comments">

                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media mb-5 pb-5 primary-comment">
                                <div class="avatar me-4">
                                    <img alt="avatar" src="<?php echo e($comment->user->profile_image ?? asset('assets/images/default_user.jpeg')); ?>" class="rounded-circle" />
                                </div>
                                <div class="media-body">
                                    <h5 class="media-heading mb-1"><?php echo e($comment->user->name ?? null); ?></h5>
                                    <div class="meta-info mb-0"><?php echo e($comment->created_at->format('d M Y')); ?></div>
                                    <p class="media-text mt-2 mb-0"><?php echo e($comment->content); ?> </p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <!-- Pagination des commentaires si nécessaire -->
                            <?php if($comments->hasPages()): ?>
                                <div class="post-pagination">
                                    <div class="pagination-no_spacing">
                                        <ul class="pagination">
                                            
                                            <?php if($comments->onFirstPage()): ?>
                                                <li class="disabled">
                                                    <a href="javascript:void(0);" class="prev">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left">
                                                            <polyline points="15 18 9 12 15 6"></polyline>
                                                        </svg>
                                                    </a>
                                                </li>
                                            <?php else: ?>
                                                <li>
                                                    <a href="<?php echo e($comments->previousPageUrl()); ?>" class="prev">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left">
                                                            <polyline points="15 18 9 12 15 6"></polyline>
                                                        </svg>
                                                    </a>
                                                </li>
                                            <?php endif; ?>

                                            
                                            <?php $__currentLoopData = $comments->links(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <?php if(is_string($element)): ?>
                                                    <li class="disabled"><a href="javascript:void(0);"><?php echo e($element); ?></a></li>
                                                <?php endif; ?>

                                                
                                                <?php if(is_array($element)): ?>
                                                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($page == $comments->currentPage()): ?>
                                                            <li><a href="javascript:void(0);" class="active"><?php echo e($page); ?></a></li>
                                                        <?php else: ?>
                                                            <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                            <?php if($comments->hasMorePages()): ?>
                                                <li>
                                                    <a href="<?php echo e($comments->nextPageUrl()); ?>" class="next">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                                            <polyline points="9 18 15 12 9 6"></polyline>
                                                        </svg>
                                                    </a>
                                                </li>
                                            <?php else: ?>
                                                <li class="disabled">
                                                    <a href="javascript:void(0);" class="next">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right">
                                                            <polyline points="9 18 15 12 9 6"></polyline>
                                                        </svg>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="text-end mt-4">
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary me-3">
                                Retour
                            </a>
                            <a href="<?php echo e(route('admin.blog.edit', $post->id)); ?>" class="btn btn-success">
                                Modifier le post
                            </a>
                        </div>                        
                        
                    </div>
                    
                </div>
            </div>
        </div> 
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/IvoirePuis87/resources/views/backend/blog/show.blade.php ENDPATH**/ ?>