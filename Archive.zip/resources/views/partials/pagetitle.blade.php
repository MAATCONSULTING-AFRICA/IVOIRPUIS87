<div class="cmt-page-title-row cmt-bgimage-yes cmt-bg cmt-bgcolor-darkgrey">
    <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
    <div class="cmt-page-title-row-inner">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="page-title-heading">
                        <h2 class="title">{{$pagetitle}}</h2>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <span>
                            <a title="Accueil" href="{{route('home')}}">Accueil</a>
                        </span>
                        <span>{{$pagetitle}}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>                    
</div>